import java.util.Scanner;
public class java6 {
    public static void main(String[] args) {

        int bath, t, h, a, n, k, y, o, u, 
        tt, hh, aa, yy, oo, uu, ttt, hhh;

        Scanner in = new Scanner(System.in);

        System.out.print("จำนวนเงิน : ");
        bath = in.nextInt();

        t = bath / 1000;
        h = bath % 1000;
        a = h / 500;
        n = h % 500;
        k = n / 100;
        y = n % 100;
        o = y / 50;
        u = y % 50;
        tt = u / 20;
        hh = u % 20;
        aa = hh / 10;
        yy = hh % 10;
        oo = yy / 5;
        uu = yy % 5;
        ttt = uu / 1;
        hhh = uu % 1;
        

        System.out.println("แบงค์ 1000 บาท จำนวน = " + t );
        System.out.println("======================");
        System.out.println("แบงค์ 500 บาท จำนวน = " + a );
        System.out.println("======================");
        System.out.println("แบงค์ 100 บาท จำนวน = " + k);
        System.out.println("======================");
        System.out.println("แบงค์ 50 บาท จำนวน = " + o );
        System.out.println("======================");
        System.out.println("แบงค์ 20 บาท จำนวน = " + tt );
        System.out.println("======================");
        System.out.println("เหรียญ 10 บาท จำนวน = " + aa );
        System.out.println("======================");
        System.out.println("เหรียญ 5 บาท จำนวน = " + oo );
        System.out.println("======================");
        System.out.println("เหรียญ 1 บาท จำนวน = " + ttt );
    }
}
// 3ทส1 015 รักสิน 