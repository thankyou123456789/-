public class Bmi1 {
    public static double Bmi(double height, double weight){
        return weight / (height * height);
    }
}
// 3ทส1 015 รักสิน 