import java.util.Scanner;

public class java5 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        String t, tt, ttt; // ชื่อสินค้า
        int h, hh, hhh; // จำนวน
        float a, aa, aaa; // ราคา

        float n, nn, nnn; // ราคารวมสินค้า
        float sum; // ราคารวมทั้งหมด
        float vat; // ภาษี

        // สินค้า 1
        System.out.print("product 1:");
        t = in.next();
        // จำนวน 1
        System.out.print("number 1:");
        h = in.nextInt();
        // ราคา 1
        System.out.print("price 1 :");
        a = in.nextFloat();
        
        // สินค้า 2
        System.out.print("product 2:");
        tt = in.next();
        // จำนวน 2
        System.out.print("number 2:");
        hh = in.nextInt();
        // ราคา 2
        System.out.print("price 2 :");
        aa = in.nextFloat();

        // สินค้า 3 
        System.out.print("product 3 :");
        ttt = in.next();
        // จำนวน 3
        System.out.print("number 3 :");
        hhh = in.nextInt();
        // ราคา 3
        System.out.print("price 3 :");
        aaa = in.nextFloat();

        n = a * h;// ราคารวม 1 
        nn = aa * hh;// ราคารวม 2 
        nnn = aaa * hhh;// ราคารวม 3
        sum = n + nn + nnn;//ราคารวมทั้งหมด
        vat = sum * 7 / 107;//(ภาษี)

        System.out.println("********************");
        System.out.println("product 1 : " + t);
        System.out.println("....................");
        System.out.println("number 1 :" + h);
        System.out.println("....................");
        System.out.println("price 1 : " + a);
        System.out.println("....................");
        System.out.println("price all 1 : " + n);
        System.out.println("********************");
        System.out.println("\n");

        System.out.println("********************");
        System.out.println("product 2 : " + tt);
        System.out.println("....................");
        System.out.println("number 2 :" + hh);
        System.out.println("....................");
        System.out.println("price 2 : " + aa);
        System.out.println("....................");
        System.out.println("price all 2 : " + nn);
        System.out.println("********************");
        System.out.println("\n");

        System.out.println("********************");
        System.out.println("product 3 : " + ttt);
        System.out.println("....................");
        System.out.println("number 3 :" + hhh);
        System.out.println("....................");
        System.out.println("price 3 : " + aaa);
        System.out.println("....................");
        System.out.println("price all 3 : " + nnn);
        System.out.println("********************");

        System.out.println("price all (vat):" + (sum + vat));
        System.out.println("(vat):" + vat);
        System.out.println("price all (no vat):" + sum);

        
    }
}
// 3ทส1 015 รักสิน 
