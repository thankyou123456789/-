import java.util.Scanner;
public class java4 {
    public static void main(String[] args) {
        long minute, week, day, hour, x;
        Scanner in = new Scanner(System.in);
        System.out.print("ใส่จำนวนนาที :");
        minute = in.nextLong();

        week = minute / 10080;

        x = minute % 10080;

        day = x / 1440;

        x = x % 1440;

        hour = x / 60;
        
        x = x % 60;

        System.out.println("นาที = " + minute);
        System.out.println("สัปดาห์ = " + week);
        System.out.println("วัน = " + day);
        System.out.println("ชั่วโมง = " + hour);
        System.out.println("นาที = " + x);

    }
}
// 3ทส1 015 รักสิน 