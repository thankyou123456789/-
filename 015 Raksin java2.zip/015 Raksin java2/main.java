import java.util.Scanner;
public class main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Enter height (m) :");
        double h = in.nextDouble();

        System.out.print("Enter weight (kg) :");
        double w = in.nextDouble();
        System.out.print(Bmi1.Bmi(h, w));
         
    }
}
// 3ทส1 015 รักสิน 